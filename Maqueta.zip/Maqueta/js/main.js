//ESTADO ACORDEON
$(".card-header").click(function() {
    $(this).toggleClass("activo");
    $(this).parents(".card").siblings().find(".card-header").removeClass("activo");
});