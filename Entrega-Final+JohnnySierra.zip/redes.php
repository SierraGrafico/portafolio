<aside class="redes">
        <p>Ver</p>
        <div class="redes__red"><a href="https://www.linkedin.com/in/sierra-grafico" target="_blank"><i
                    class="bi bi-linkedin"></i></a></div>
        <div class="redes__red"><a href="https://www.facebook.com/SierraGrafico/" target="_blank"><i
                    class="bi bi-facebook"></i></a></div>
    </aside>