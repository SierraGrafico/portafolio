<?php include('header.php'); ?>

<body class="gracias">
    <?php include('menu.php'); ?>
    <?php include('redes.php'); ?>
    <main>
    <h2>¡Gracias!</h2>
</main>
        <?php include('footer.php'); ?>